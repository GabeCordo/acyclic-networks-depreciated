# Python Node Tor
*A mid-weight framework for replicating tor entry, relay and exit nodes. Developed for programmers looking to provide highly-secure messaging/file transfer applications. Equipt with end-to-end encryption and anonymous server meshing.*

	pip install pynodetor==1.1
	
## Credits

pynodetor
> Gabriel Cordovado

	Functionality of all classes are not limited to this README, I encourage your to view the source :octocat:
